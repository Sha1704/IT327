import Product from "./ProductClass.js";
const newProduct = new Product();
console.log(newProduct.displayInfo());
